package com.Pages;

import org.openqa.selenium.By;
import Utility.TestBase_Commands;
import io.appium.java_client.android.AndroidDriver;

public class LoginPage extends TestBase_Commands {

	private By tf_PhoneNumber = By.xpath("//android.widget.EditText[@text='Phone number']");
	private By tf_PinNumber = By.xpath("//android.widget.EditText[@text='Pin number']");
	private By btn_Submit = By.xpath("//android.widget.TextView[@text='Submit']");

	public LoginPage(AndroidDriver driver) {
		this.driver = driver;
	}
	
	//Login to application
	public void bf_Login(String prm_phoneNumber, String prm_pinNumber) {
		Type(tf_PhoneNumber, prm_phoneNumber);
		CheckElementPresent(btn_Submit);
		Tap(btn_Submit);
		VerifyText(tf_PinNumber, "Pinnumber");
		Type(tf_PinNumber, prm_pinNumber);
		Tap(btn_Submit);
	}
}