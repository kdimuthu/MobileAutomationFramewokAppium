package com.TestCases;

import org.testng.annotations.Test;
import com.Pages.LoginPage;
import Utility.AppiumTestBase;
import Utility.ExcelReader;

public class LoginPage_Tests extends AppiumTestBase {

	LoginPage _LoginPage;

	//login to application
	@Test(priority = 1, enabled = true)
	public void tc_Verifylogin() {
		_LoginPage = new LoginPage(driver);
		_LoginPage.bf_Login(ExcelReader.getData(0, 1, 0), ExcelReader.getData(0, 1, 1));

	}

}
